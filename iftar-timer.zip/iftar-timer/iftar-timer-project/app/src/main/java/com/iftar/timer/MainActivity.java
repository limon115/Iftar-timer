package com.iftar.timer;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.iftar.timer.util.LocationManager;
import com.iftar.timer.util.PrayerTimeCalculator;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    private TextView countdownTextView;
    private TextView maghribTextView;
    private TextView locationTextView;
    private Button refreshButton;

    private LocationManager locationManager;
    private Handler handler;
    private Runnable countdownRunnable;

    private Location currentLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        countdownTextView = findViewById(R.id.countdown_text);
        maghribTextView = findViewById(R.id.maghrib_time);
        locationTextView = findViewById(R.id.location_text);
        refreshButton = findViewById(R.id.refresh_button);

        // Initialize managers
        locationManager = new LocationManager(this);
        handler = new Handler(Looper.getMainLooper());

        // Request location permission if needed
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST_CODE);
            } else {
                initializeApp();
            }
        } else {
            initializeApp();
        }

        // Refresh button listener
        refreshButton.setOnClickListener(v -> refreshLocation());
    }

    private void initializeApp() {
        // Get location
        currentLocation = locationManager.getSavedOrDefaultLocation();
        locationTextView.setText(locationManager.getSavedCityName());

        // Request fresh location update
        locationManager.requestLocationUpdate(this, new LocationManager.LocationCallback() {
            @Override
            public void onLocationReceived(Location location) {
                currentLocation = location;
                runOnUiThread(() -> {
                    locationTextView.setText(locationManager.getSavedCityName());
                    updateCountdown();
                });
            }

            @Override
            public void onLocationFailed() {
                // Use saved/default location
                currentLocation = locationManager.getSavedOrDefaultLocation();
                runOnUiThread(() -> updateCountdown());
            }
        });

        // Start countdown updates
        startCountdownTimer();
    }

    private void startCountdownTimer() {
        countdownRunnable = new Runnable() {
            @Override
            public void run() {
                updateCountdown();
                handler.postDelayed(this, 60000); // Update every minute
            }
        };
        handler.post(countdownRunnable);
    }

    private void updateCountdown() {
        if (currentLocation == null) {
            currentLocation = locationManager.getSavedOrDefaultLocation();
        }

        Calendar calendar = Calendar.getInstance();
        PrayerTimeCalculator calculator = new PrayerTimeCalculator(
                currentLocation.getLatitude(),
                currentLocation.getLongitude()
        );

        // Get today's Maghrib time
        int maghribMinutes = calculator.getMaghribTimeInMinutes(calendar);

        // Get countdown
        int countdownMinutes = PrayerTimeCalculator.getCountdownMinutes(calendar, maghribMinutes);

        // If passed, get next day's countdown
        if (countdownMinutes == 0) {
            countdownMinutes = PrayerTimeCalculator.getMinutesUntilNextMaghrib(calendar, maghribMinutes);
        }

        // Update UI
        int hours = countdownMinutes / 60;
        int minutes = countdownMinutes % 60;

        countdownTextView.setText(String.format("%02d:%02d", hours, minutes));
        maghribTextView.setText("Maghrib: " + PrayerTimeCalculator.formatTime(maghribMinutes));
    }

    private void refreshLocation() {
        Toast.makeText(this, "Updating location...", Toast.LENGTH_SHORT).show();

        locationManager.requestLocationUpdate(this, new LocationManager.LocationCallback() {
            @Override
            public void onLocationReceived(Location location) {
                currentLocation = location;
                runOnUiThread(() -> {
                    locationTextView.setText(locationManager.getSavedCityName());
                    updateCountdown();
                    Toast.makeText(MainActivity.this,
                            "Location updated: " + locationManager.getSavedCityName(),
                            Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onLocationFailed() {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Location update failed. Using saved location.",
                        Toast.LENGTH_SHORT).show());
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                          @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeApp();
            } else {
                // Permission denied - use default location
                currentLocation = locationManager.getSavedOrDefaultLocation();
                locationTextView.setText(locationManager.getSavedCityName());
                startCountdownTimer();
                Toast.makeText(this, "Location permission denied. Using Dhaka.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCountdown();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (countdownRunnable != null) {
            handler.removeCallbacks(countdownRunnable);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countdownRunnable != null) {
            handler.removeCallbacks(countdownRunnable);
        }
    }
}
