# FILE MANIFEST - IFTAR TIMER PROJECT

## Complete List of All 33+ Files with Descriptions

### 📂 ROOT LEVEL FILES

#### Configuration & Build Files
```
build.gradle (4 KB)
├── Purpose: Project-level Gradle configuration
├── Contains: Plugin versions (Android Gradle Plugin 8.1.2)
├── Role: Top-level build configuration for entire project
└── Modified by: Users upgrading Gradle or plugin versions
```

```
settings.gradle (0.5 KB)
├── Purpose: Gradle settings and repository configuration
├── Contains: Root project name "IftarTimer", module includes
├── Role: Defines project structure for Gradle
└── Key content: Repository setup (mavenCentral, google)
```

```
gradlew (5.8 KB)
├── Purpose: Gradle wrapper script for Unix/Linux/macOS
├── Usage: ./gradlew assembleDebug
├── Role: Downloads and executes correct Gradle version
├── No modification needed: Pre-configured
```

```
gradlew.bat (2.2 KB)
├── Purpose: Gradle wrapper script for Windows
├── Usage: gradlew.bat assembleDebug
├── Role: Windows equivalent of gradlew
├── No modification needed: Pre-configured
```

```
.gitignore (2 KB)
├── Purpose: Git ignore rules for repository
├── Contains: .gradle/, build/, .idea/, *.apk, etc.
├── Role: Prevents committing build artifacts
└── Usage: Prevents polluting Git repository
```

```
README.md (8 KB)
├── Purpose: Project overview and documentation
├── Contains: Features, installation, usage, customization
├── Role: Main documentation file
└── Audience: Developers and end-users
```

```
SETUP.md (15 KB)
├── Purpose: Detailed setup and deployment guide
├── Contains: Prerequisites, installation, building, testing
├── Role: Complete setup instructions
└── Audience: Developers setting up environment
```

```
PROJECT_STRUCTURE.md (6 KB)
├── Purpose: File structure reference
├── Contains: Directory tree, file summary
├── Role: Technical documentation
└── Audience: Developers understanding project layout
```

```
START_HERE.md (10 KB)
├── Purpose: Quick start guide (THIS FILE)
├── Contains: Quick start, feature overview, specifications
├── Role: Entry point for new developers
└── Audience: Everyone starting with project
```

---

### 📂 .github/ Directory

```
.github/workflows/android-build.yml (1.5 KB)
├── Purpose: GitHub Actions CI/CD workflow
├── Contains: Build steps, artifact upload configuration
├── Trigger: Push to main branch
├── Output: APK artifact available for download
├── Jobs: Java setup, Gradle build, APK upload
```

---

### 📂 gradle/ Directory

```
gradle/wrapper/gradle-wrapper.properties (0.5 KB)
├── Purpose: Gradle wrapper configuration
├── Contains: Gradle version (8.0), distribution URL
├── Role: Specifies which Gradle version to use
└── Auto-download: If not present, downloads automatically
```

---

### 📂 app/ Directory - Main Application

#### Build Configuration

```
app/build.gradle (3 KB)
├── Purpose: App-level Gradle configuration
├── Contains: 
│   ├── Android SDK settings (min 21, target 34)
│   ├── App ID (com.iftar.timer)
│   ├── Version code/name (1/1.0.0)
│   ├── Dependencies (AndroidX, Material, Google Play Services)
│   └── Compiler options (Java 11)
├── Role: Defines app building parameters
└── Critical: Version number, dependencies, SDK levels
```

```
proguard-rules.pro (0.3 KB)
├── Purpose: ProGuard/R8 minification rules
├── Contains: Comments for future optimization rules
├── Role: Code obfuscation for release builds
└── Currently: Minification disabled (debug mode)
```

---

### 📂 app/src/main/ - Application Source

#### Manifest

```
app/src/main/AndroidManifest.xml (2.5 KB)
├── Purpose: Android app manifest/declaration
├── Contains:
│   ├── Permissions: ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION, INTERNET
│   ├── Activities: MainActivity
│   ├── Receivers: IftarWidgetProvider, WidgetUpdateReceiver
│   ├── Widget metadata reference
│   └── Uses-feature declarations
├── Role: Declares app components and permissions
└── Critical: Every component must be registered here
```

---

### 📂 app/src/main/java/ - Java Source Code

#### Core Activity

```
app/src/main/java/com/iftar/timer/MainActivity.java (4 KB)
├── Purpose: Main activity - countdown display
├── Imports: Android core, location services, widgets
├── Key Methods:
│   ├── onCreate() - Initialize UI and managers
│   ├── initializeApp() - Setup location and countdown
│   ├── startCountdownTimer() - Update countdown every minute
│   ├── updateCountdown() - Refresh display values
│   ├── refreshLocation() - Manual location update
│   ├── onRequestPermissionsResult() - Handle permission grants
│   └── Lifecycle methods (onResume, onPause, onDestroy)
├── UI Elements:
│   ├── countdownTextView - Large countdown display
│   ├── maghribTextView - Prayer time display
│   ├── locationTextView - Current location
│   └── refreshButton - Location refresh button
├── Key Features:
│   ├── Permission handling (Android 6+)
│   ├── Location manager integration
│   ├── Prayer time calculations
│   └── Automatic updates every 60 seconds
└── Handler: Uses Handler/Looper for UI updates
```

#### Utility Classes

```
app/src/main/java/com/iftar/timer/util/PrayerTimeCalculator.java (5 KB)
├── Purpose: Astronomical prayer time calculations
├── Imports: Java calendar and math utilities
├── Key Methods:
│   ├── getMaghribTimeInMinutes() - Calculate sunset time
│   ├── calculateDeclination() - Sun declination for day
│   ├── calculateTimeDifference() - Timezone offset
│   ├── calculatePrayerAngle() - Prayer angle calculation
│   ├── getCountdownMinutes() - Minutes until Maghrib
│   └── getMinutesUntilNextMaghrib() - For passed times
├── Static Methods:
│   ├── formatTime() - Convert minutes to HH:MM
│   └── Various calculation helpers
├── Algorithm: ISNA (Islamic Society of North America)
├── Accuracy: ±2 minutes
└── Dependencies: Java Math library (no external APIs)
```

```
app/src/main/java/com/iftar/timer/util/LocationManager.java (5.5 KB)
├── Purpose: Location/GPS handling
├── Imports: Google Play Services Location, Android core, SharedPreferences
├── Key Methods:
│   ├── getLastKnownLocation() - Retrieve cached/device location
│   ├── requestLocationUpdate() - Request fresh GPS location
│   ├── getSavedOrDefaultLocation() - Get saved or fallback
│   ├── saveLocation() - Cache location locally
│   ├── getSavedCityName() - Retrieve city name
│   ├── getCityName() - Map coordinates to city
│   └── hasLocationPermissions() - Check permission status
├── Classes Used:
│   ├── FusedLocationProviderClient - Modern Google Location API
│   ├── SharedPreferences - Local data storage
│   ├── Location - Location data object
│   └── Callback interface - Async location updates
├── Default Location: Dhaka, Bangladesh (23.8103°N, 90.2293°E)
├── Storage: SharedPreferences "iftar_timer_prefs"
└── Fallback: Uses cached location if GPS unavailable
```

#### Widget Classes

```
app/src/main/java/com/iftar/timer/widget/IftarWidgetProvider.java (4.5 KB)
├── Purpose: Home screen widget provider
├── Extends: AppWidgetProvider
├── Key Methods:
│   ├── onUpdate() - Called when widget updates
│   ├── onReceive() - Handle widget broadcasts
│   ├── updateWidget() - Refresh widget display
│   └── scheduleNextUpdate() - Schedule next update with AlarmManager
├── Widget Features:
│   ├── Displays: Countdown (HH:MM), Maghrib time
│   ├── Updates: Every 60 seconds via AlarmManager
│   ├── Click Handler: Opens MainActivity on tap
│   ├── PendingIntent: FLAG_IMMUTABLE for Android 12+
│   └── Remote Views: UpdatesUI without app running
├── Location: Uses cached location from LocationManager
├── Prayer Calculation: Uses PrayerTimeCalculator for widget display
└── Offline: Completely offline after location obtained
```

```
app/src/main/java/com/iftar/timer/widget/WidgetUpdateReceiver.java (1.5 KB)
├── Purpose: Broadcast receiver for widget updates
├── Extends: BroadcastReceiver
├── Key Methods:
│   └── onReceive() - Handle update broadcasts
├── Action Filter: "com.iftar.timer.UPDATE_WIDGET"
├── Role: Supplements AlarmManager for widget updates
└── Fallback: Additional update mechanism if system triggers
```

---

### 📂 app/src/main/res/layout/ - UI Layouts

```
app/src/main/res/layout/activity_main.xml (2.5 KB)
├── Purpose: Main activity UI layout
├── Type: LinearLayout (vertical)
├── Root Attributes:
│   ├── Background: ?attr/colorBackground
│   ├── Padding: 24dp
│   └── Orientation: vertical
├── UI Components:
│   ├── Space (Top spacer for vertical centering)
│   ├── TextView (location_text) - Current location/city
│   ├── TextView (label) - "IFTAR" text
│   ├── TextView (countdown_text) - Large countdown HH:MM
│   │   ├── Size: 72sp bold
│   │   ├── Color: colorPrimary (green)
│   │   ├── Font: Monospace
│   │   └── Gravity: Center
│   ├── TextView (maghrib_time) - Prayer time display
│   ├── Space (Vertical spacer)
│   ├── Button (refresh_button) - Location refresh button
│   └── TextView (info_text) - App description
├── Layout Attributes:
│   ├── Weight distribution for spacing
│   ├── Margins between elements
│   └── Text alignment (center)
└── Responsive: Works on all screen sizes, portrait orientation
```

```
app/src/main/res/layout/widget_iftar.xml (1.2 KB)
├── Purpose: Home screen widget layout
├── Root: FrameLayout
│   ├── Background: widget_glass_bg drawable
│   ├── Padding: 16dp
│   └── ID: widget_root (clickable)
├── Content: LinearLayout (nested, centered)
│   ├── Gravity: center
│   ├── Padding: 20dp
│   └── Orientation: vertical
├── Widget UI Elements:
│   ├── TextView (label) - "IFTAR"
│   │   ├── Size: 12sp
│   │   ├── Color: White
│   │   ├── Alpha: 0.7 (translucent)
│   │   └── Style: Bold
│   ├── TextView (countdown) - HH:MM countdown
│   │   ├── Size: 48sp
│   │   ├── Color: White
│   │   ├── Style: Bold
│   │   └── Gravity: center
│   └── TextView (maghrib_time) - Prayer time
│       ├── Size: 14sp
│       ├── Color: White
│       ├── Alpha: 0.8
│       └── Gravity: center
├── Click Handler: Calls MainActivity via PendingIntent
└── RemoteViews: Updated by IftarWidgetProvider
```

---

### 📂 app/src/main/res/drawable/ - Drawable Resources

```
app/src/main/res/drawable/ic_launcher_foreground.xml (0.6 KB)
├── Purpose: App launcher icon foreground
├── Type: Vector drawable
├── Design: Clock/timer icon
├── Colors: White foreground
├── Size: 108x108dp
├── Usage: Icon foreground in adaptive icon
└── Format: Scalable to any resolution
```

```
app/src/main/res/drawable/ic_launcher_background.xml (0.3 KB)
├── Purpose: App launcher icon background
├── Type: Vector drawable with solid color
├── Color: Primary green (#2E7D32)
├── Size: 108x108dp
├── Usage: Icon background in adaptive icon
└── Format: Solid color, no scaling needed
```

```
app/src/main/res/drawable/widget_glass_bg.xml (0.4 KB)
├── Purpose: Glass morphism background for widget
├── Type: Shape drawable (rectangle)
├── Key Attributes:
│   ├── Solid Color: #4DFFFFFF (white, ~30% opacity)
│   ├── Stroke: 0.5dp, #80FFFFFF (border)
│   ├── Corners: 28dp radius (rounded)
│   └── Padding: Applied via layout
├── Style: Samsung One UI glass effect
├── Compatibility: API 16+
└── Effect: Semi-transparent glass look on any wallpaper
```

```
app/src/main/res/drawable/widget_preview.xml (0.3 KB)
├── Purpose: Widget preview image in widget list
├── Type: Shape drawable (dark rectangle)
├── Color: #1a1a1a (dark gray/black)
├── Corners: 28dp rounded
├── Usage: Shown in "Add Widget" dialog
└── Note: Placeholder, could be replaced with actual image
```

---

### 📂 app/src/main/res/values/ - String & Color Resources

```
app/src/main/res/values/strings.xml (0.4 KB)
├── Purpose: Localizable string resources
├── Strings Defined:
│   ├── app_name = "Iftar Timer"
│   ├── iftar_label = "IFTAR"
│   ├── default_location = "Dhaka, Bangladesh"
│   ├── maghrib_time_default = "Maghrib: --:--"
│   ├── refresh_location = "Refresh Location"
│   ├── app_info = "Countdown to Iftar..."
│   └── widget_name = "Iftar Timer"
├── Localization: Ready for translation
└── Usage: Referenced via @string/string_name in layouts
```

```
app/src/main/res/values/colors.xml (0.7 KB)
├── Purpose: Color definitions
├── Colors Defined:
│   ├── primary = #2E7D32 (green)
│   ├── primary_variant = #1B5E20 (dark green)
│   ├── secondary = #26A69A (teal)
│   ├── secondary_variant = #00897B (dark teal)
│   ├── background = #FFFFFF (white)
│   ├── surface = #FAFAFA (light gray)
│   ├── on_background = #1F1F1F (dark text)
│   ├── secondary_text = #757575 (gray text)
│   └── status bar colors
├── Material Design: Follows Material 3 guidelines
├── Theme: Light theme with green accent
└── Customization: Easy color changes
```

```
app/src/main/res/values/styles.xml (1.2 KB)
├── Purpose: App themes and styles
├── Themes Defined:
│   ├── Theme.IftarTimer (parent: Theme.AppCompat.Light.DarkActionBar)
│   │   ├── Color attributes (primary, secondary, background)
│   │   ├── Text colors
│   │   ├── Action bar styling
│   │   ├── Status bar color
│   │   └── Button styling
│   │
│   ├── ActionBarStyle (custom toolbar)
│   │   ├── Background: primary color
│   │   ├── Elevation: 4dp shadow
│   │   └── Typography settings
│   │
│   └── MaterialButtonStyle (custom buttons)
│       ├── Text color: white
│       ├── Background: primary
│       └── Standard Material styling
├── Inheritance: From AppCompat for compatibility
├── Customization: Modify colors in colors.xml
└── Application: Applied in AndroidManifest.xml
```

---

### 📂 app/src/main/res/xml/ - Configuration XMLs

```
app/src/main/res/xml/iftar_widget_info.xml (0.5 KB)
├── Purpose: Widget metadata configuration
├── Type: AppWidget provider declaration
├── Attributes:
│   ├── minWidth: 250dp
│   ├── minHeight: 100dp
│   ├── updatePeriodMillis: 3600000 (1 hour system default)
│   ├── widgetCategory: home_screen
│   ├── resizeMode: horizontal|vertical (resizable)
│   ├── targetCellWidth: 4 (grid width)
│   ├── targetCellHeight: 2 (grid height)
│   ├── previewImage: widget_preview drawable
│   └── configure: (empty - no configuration activity)
├── Usage: Referenced in AndroidManifest.xml
└── Note: Actual updates via AlarmManager (more frequent)
```

```
app/src/main/res/xml/backup_rules.xml (0.4 KB)
├── Purpose: Android 12+ backup configuration
├── Type: Full backup content declaration
├── Contains:
│   └── domain "sharedpref" included (backup preferences)
├── Usage: Data preservation on app updates/reinstall
├── Domains: Sharedpref, database, file, etc.
└── Security: Specifies what data is backed up
```

```
app/src/main/res/xml/data_extraction_rules.xml (0.4 KB)
├── Purpose: Android 12+ data extraction rules
├── Type: Domain-specific data security
├── Attributes:
│   ├── cleartextTrafficPermitted: false
│   ├── domain: example.com (placeholder)
│   └── includeSubdomains: true
├── Usage: Auto-backup to cloud services
├── Security: Prevents unencrypted network traffic
└── Note: Currently minimal, can be expanded
```

---

### 📂 app/src/main/res/mipmap-* - App Icons

```
app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml (0.4 KB)
├── Purpose: Adaptive app icon (Android 8+)
├── Type: Adaptive icon declaration
├── Components:
│   ├── background: ic_launcher_background.xml
│   ├── foreground: ic_launcher_foreground.xml
│   └── monochrome: ic_launcher_foreground.xml
├── Compatibility: Android 8+ (API 26+)
├── Scaling: Automatically adapts to device shape
└── Usage: Main launcher icon on modern devices
```

```
app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml (0.4 KB)
├── Purpose: Round variant of adaptive icon
├── Type: Adaptive icon (same components)
├── Components: Same as ic_launcher.xml
├── Shape: Round icon variant
├── Compatibility: Android 8+ (API 26+)
└── Usage: Round icon option on devices that support it
```

```
app/src/main/res/mipmap-anydpi-v33/ic_launcher.xml (0.4 KB)
├── Purpose: Modern adaptive icon (Android 13+)
├── Type: Adaptive icon with theming
├── Components:
│   ├── background: ic_launcher_background.xml
│   ├── foreground: ic_launcher_foreground.xml
│   └── monochrome: For themed icon support
├── Compatibility: Android 13+ (API 33+)
├── Features: Themed icons (follows system theme)
└── Usage: Latest Android devices
```

---

### 📂 app/src/test/ - Unit Tests

```
app/src/test/ (empty directory)
├── Purpose: Unit test location
├── Ready for: JUnit tests
├── Examples:
│   ├── PrayerTimeCalculatorTest.java (not included)
│   └── LocationManagerTest.java (not included)
├── Execution: ./gradlew test
└── Note: Can be added by user for validation
```

---

## 📊 FILE STATISTICS

### By Type
- **Java Source**: 5 files (25 KB)
- **XML Resources**: 13 files (15 KB)
- **Gradle Config**: 4 files (8 KB)
- **Documentation**: 4 files (45 KB)
- **Scripts**: 2 files (8 KB)
- **Total**: 33 files (77 KB)

### By Location
- **Root**: 8 files
- **.github/**: 1 file
- **gradle/**: 1 file
- **app/**: 23 files (organized in subdirectories)

### By Purpose
- **Configuration**: 5 files
- **Source Code**: 5 files
- **Layouts**: 2 files
- **Drawable Resources**: 4 files
- **Value Resources**: 3 files
- **Configuration XMLs**: 3 files
- **App Icons**: 3 files
- **CI/CD**: 1 file
- **Documentation**: 4 files
- **Build Scripts**: 2 files
- **Utilities**: 2 files (.gitignore, proguard)

---

## 🔑 KEY FILE RELATIONSHIPS

### Manifest -> Components
```
AndroidManifest.xml
├── Declares MainActivity
├── Declares IftarWidgetProvider
├── Declares WidgetUpdateReceiver
└── Lists Permissions: LOCATION, INTERNET
```

### MainActivity -> Utilities
```
MainActivity.java
├── Uses LocationManager (location/GPS)
├── Uses PrayerTimeCalculator (prayer times)
├── Updates UI from countdown logic
└── Calls Handlers for periodic updates
```

### IftarWidgetProvider -> Utilities
```
IftarWidgetProvider.java
├── Uses LocationManager (get location)
├── Uses PrayerTimeCalculator (calculate time)
├── Updates RemoteViews (widget UI)
└── Schedules AlarmManager (updates)
```

### Layouts -> Drawables & Values
```
activity_main.xml
├── References strings.xml (text)
├── References colors.xml (colors)
└── References styles.xml (theme)

widget_iftar.xml
├── References widget_glass_bg.xml (background)
├── References strings.xml (IFTAR label)
└── No drawable references (RemoteViews updated programmatically)
```

---

## 🔒 File Permissions

### Executable Scripts
- `gradlew` - Must be executable
- `gradlew.bat` - Executable (Windows)

### Read-Only (In Version Control)
- All `.xml` files
- All `.java` files
- `build.gradle` files
- Documentation

### Generated (Not in Version Control)
- `.gradle/` directory
- `build/` directory
- `.idea/` directory
- `*.apk` files

---

## 📝 Modification Guide

### What to Modify
| File | When | How |
|------|------|-----|
| **colors.xml** | Change app colors | Edit color hex values |
| **strings.xml** | Change text | Edit string values |
| **MainActivity.java** | Change UI logic | Edit Java code |
| **LocationManager.java** | Change default location | Edit coordinates |
| **widget_glass_bg.xml** | Change widget appearance | Edit opacity/radius |

### What NOT to Modify
| File | Reason |
|------|--------|
| **gradlew** | Pre-configured build script |
| **gradle-wrapper.properties** | Defines Gradle version |
| **AndroidManifest.xml** | Unless adding components |
| **build.gradle** | Unless changing dependencies |

---

## ✅ File Checklist

**Core Files** (Must have)
- [ ] build.gradle (both levels)
- [ ] settings.gradle
- [ ] AndroidManifest.xml
- [ ] MainActivity.java
- [ ] All drawable XMLs
- [ ] All layout XMLs
- [ ] strings.xml, colors.xml
- [ ] gradle wrapper files

**Widget Support** (For widget functionality)
- [ ] IftarWidgetProvider.java
- [ ] WidgetUpdateReceiver.java
- [ ] widget_iftar.xml
- [ ] widget_glass_bg.xml
- [ ] iftar_widget_info.xml

**Utilities** (For prayer calculations and location)
- [ ] PrayerTimeCalculator.java
- [ ] LocationManager.java

**CI/CD** (For automated builds)
- [ ] .github/workflows/android-build.yml

**Documentation** (For setup and understanding)
- [ ] README.md
- [ ] SETUP.md
- [ ] PROJECT_STRUCTURE.md
- [ ] START_HERE.md (or this manifest)

---

## 🚀 Next Steps

1. **Understand Structure**: Read START_HERE.md
2. **Setup Environment**: Follow SETUP.md
3. **Build Project**: `./gradlew assembleDebug`
4. **Install & Test**: Deploy APK to device
5. **Customize**: Modify colors, location, strings
6. **Deploy**: Push to GitHub for CI/CD builds

---

*Complete File Manifest - February 2026*
*Total Files: 33+ (including generated documentation)*
*Project Size: ~77 KB source + variable build output*
