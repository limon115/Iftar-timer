# SETUP & DEPLOYMENT GUIDE - IFTAR TIMER

## Prerequisites

### System Requirements
- Windows, macOS, or Linux
- 8GB RAM minimum (16GB recommended)
- 5GB free disk space
- Internet connection (initial setup only)

### Software Requirements
- **Java Development Kit (JDK)** 11 or higher
  - Download: https://adoptopenjdk.net/ or https://www.oracle.com/java/technologies/downloads/
  - Verify: `java -version`
  
- **Android Studio** 2021.1 or later
  - Download: https://developer.android.com/studio
  
- **Android SDK** (included with Android Studio)
  - Minimum SDK: 21 (Android 5.0)
  - Target SDK: 34 (Android 14)
  - Platform version: API 34

- **Git** (for GitHub)
  - Download: https://git-scm.com/

## Installation Steps

### 1. Extract Project Files

```bash
# Clone from GitHub (or download ZIP)
git clone https://github.com/yourusername/iftar-timer.git
cd iftar-timer
```

**OR**

```bash
# Extract from ZIP file
unzip iftar-timer.zip
cd iftar-timer
```

### 2. Verify Gradle Wrapper

The project includes Gradle wrapper scripts (`gradlew` and `gradlew.bat`).

**On Linux/macOS:**
```bash
chmod +x gradlew
```

**On Windows:** (No action needed, use `gradlew.bat`)

### 3. Open in Android Studio

1. **File** → **Open** → Select `iftar-timer` folder
2. Wait for Gradle sync (may take 2-5 minutes)
3. Android Studio will automatically download dependencies

### 4. Configure Android SDK

If you see "SDK not found" errors:

1. **File** → **Settings** → **Appearance & Behavior** → **System Settings** → **Android SDK**
2. Under "SDK Platforms" tab:
   - ✓ Check "Android 14 (API 34)"
   - ✓ Check "Android 12 (API 31)" or later for widget support
3. Click **Apply** → **OK**

### 5. Grant Gradle Wrapper Permission (Linux/macOS)

```bash
chmod +x gradlew
./gradlew --version  # Should print Gradle version
```

## Building the APK

### Method 1: Using Android Studio GUI

1. Connect Android device (optional - can build without)
2. **Build** menu → **Build Bundle(s) / APK(s)** → **Build APK(s)**
3. Wait for build to complete (~2 minutes)
4. Notification will show: "Build successful"

APK location: `app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Using Gradle Command Line

```bash
# Build debug APK
./gradlew assembleDebug

# OR on Windows
gradlew assembleDebug

# Output: app/build/outputs/apk/debug/app-debug.apk
```

### Method 3: Using GitHub Actions (Automated)

1. Push code to GitHub on `main` branch
2. Go to repository → **Actions** tab
3. Click latest "Build Android APK" workflow
4. Download APK from **Artifacts** section

**No local setup needed!** - Fully automated builds.

## Installing on Device/Emulator

### Option 1: Using Android Studio

1. **Run** menu → **Run 'app'**
2. Select device from popup
3. App installs and launches automatically

### Option 2: Using ADB (Command Line)

```bash
# List connected devices
adb devices

# Install APK
adb install app/build/outputs/apk/debug/app-debug.apk

# Or push and install
adb install-multiple app/build/outputs/apk/debug/app-debug.apk

# Launch app
adb shell am start -n com.iftar.timer/.MainActivity
```

### Option 3: Manual Installation

1. Transfer `app-debug.apk` to phone via:
   - USB cable
   - Email
   - Cloud storage (Google Drive, etc.)

2. Open file manager on phone
3. Tap APK file to install
4. Grant permissions when prompted

## First Run

### Initial Setup

1. **Launch** the app
2. **Grant Location Permission**:
   - Dialog appears asking for location access
   - Tap "**Allow**" to enable GPS
   - App immediately starts calculating Maghrib

3. **Set Home Widget** (optional):
   - Long press home screen
   - Tap "**Widgets**" or "**Add Widget**"
   - Search "**Iftar Timer**"
   - Drag widget to home screen
   - Widget starts showing countdown

### Without Location Permission

If you deny location permission:
- App uses Dhaka, Bangladesh (default)
- Shows location as "Dhaka, Bangladesh"
- Can manually enable location later in Settings

## Configuration

### Change Default Location

Edit `app/src/main/java/com/iftar/timer/util/LocationManager.java`:

```java
private static final double DEFAULT_LATITUDE = 23.8103;   // Change this
private static final double DEFAULT_LONGITUDE = 90.2293;  // Change this
```

Common Bangladesh cities:
- **Dhaka**: 23.8103°N, 90.2293°E
- **Chittagong**: 22.3569°N, 91.7832°E
- **Khulna**: 22.8456°N, 89.5680°E
- **Sylhet**: 24.8997°N, 91.8703°E

After changes, rebuild:
```bash
./gradlew clean assembleDebug
```

### Change Widget Appearance

Widget colors: `app/src/main/res/drawable/widget_glass_bg.xml`

```xml
<!-- Change these values -->
<solid android:color="#4DFFFFFF" />        <!-- Background (ARGB) -->
<stroke android:width="0.5dp"              <!-- Border -->
    android:color="#80FFFFFF" />
<corners android:radius="28dp" />          <!-- Corner radius -->
```

Text colors: `app/src/main/res/values/strings.xml`

## Testing

### Unit Tests

```bash
# Run unit tests
./gradlew test

# Run instrumented tests
./gradlew connectedAndroidTest
```

### Manual Testing Checklist

- [ ] App launches without crash
- [ ] Location permission works
- [ ] Countdown displays correctly
- [ ] Maghrib time shows correct time
- [ ] "Refresh Location" button works
- [ ] Widget appears in widget list
- [ ] Widget updates every minute
- [ ] Tapping widget opens main app
- [ ] App works offline after location obtained
- [ ] Android 12+ permissions handled correctly

### Testing with Emulator

1. **Tools** → **AVD Manager** → **Create Virtual Device**
2. Select device (e.g., Pixel 6)
3. Select API 34
4. Click **Finish**
5. Click **Play** button to start emulator
6. In Android Studio: **Run** → **Run 'app'** → Select emulator

**Note:** Emulator location defaults to Google HQ (Mountain View, CA). Use extended controls to change:
- Emulator window → **...** (three dots) → **Extended controls** → **Location**

## Troubleshooting

### Build Fails: "SDK not found"
```bash
# Solution: Install SDK
./gradlew --version  # Downloads SDK automatically
# OR manually install in Android Studio (see above)
```

### Build Fails: "Permission denied" (gradlew)
```bash
# Solution: Make executable
chmod +x gradlew
./gradlew assembleDebug
```

### Build Fails: "Out of memory"
```bash
# Solution: Increase heap size
# Create/edit gradle.properties:
org.gradle.jvmargs=-Xmx2048m

# Or on command line:
./gradlew assembleDebug -Xmx2048m
```

### App Crashes on Launch
1. Check permissions in AndroidManifest.xml
2. Verify Location permissions granted in system Settings
3. Check Android Studio logcat: **View** → **Tool Windows** → **Logcat**
4. Look for red errors starting with "FATAL"

### Widget Not Appearing in List
1. Rebuild and reinstall: `./gradlew uninstallDebug assembleDebug`
2. Restart device
3. Long-press home screen → Widgets → Search "Iftar"
4. If still missing, check: **Settings** → **Apps** → **Iftar Timer** → **Permissions** → **Location** → ✓ Allow

### Location Always Shows Dhaka
1. **Settings** → **Apps** → **Iftar Timer** → **Permissions**
2. Ensure **Location** has permission
3. Try "Refresh Location" button in app
4. Go outside (needs clear sky for GPS lock, ~30-60 seconds)

### Widget Not Updating
1. Check: **Settings** → **Battery** → **Battery Optimization** → **Iftar Timer** → **Don't Optimize**
2. Check: **Settings** → **Apps** → **Advanced** → **Alarm & Reminder** → ✓ Iftar Timer
3. Manually restart device

## Development Tips

### Debugging in Android Studio

1. Set breakpoint: Click left margin next to code
2. **Run** → **Debug 'app'** (or press Shift+F9)
3. Use **Debug** toolbar to step through code
4. View variables in **Variables** panel

### Logcat Filtering

```bash
# Android Studio Logcat filter:
package:com.iftar.timer

# Or via command line:
adb logcat com.iftar.timer:V *:S
```

### Device Logs

```bash
# View system logs
adb logcat

# Save logs to file
adb logcat > app.log

# View app crashes
adb logcat | grep FATAL
```

## Release Build (Optional)

### Prerequisites
- Keystore file (digital signature)
- Keystore password

### Creating Keystore

```bash
# First time only
keytool -genkey -v -keystore release.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias release

# Follow prompts:
# Enter keystore password: [YOUR PASSWORD]
# Confirm: [YOUR PASSWORD]
# First/Last Name: [Your Name]
# ...etc
```

### Building Release APK

1. Create `app/keystore.properties`:
```properties
storeFile=../release.keystore
storePassword=YOUR_PASSWORD
keyAlias=release
keyPassword=YOUR_PASSWORD
```

2. Build:
```bash
./gradlew assembleRelease
```

3. Output: `app/build/outputs/apk/release/app-release.apk`

**⚠️ WARNING:** Never commit `keystore.properties` to Git!

## File Organization

After setup, your directory should look like:

```
iftar-timer/
├── .gradle/                    (Generated)
├── build/                      (Generated)
├── app/build/                  (Generated - APKs here)
├── .git/                       (If cloned from Git)
├── .github/
├── gradle/
├── app/
├── build.gradle
├── README.md
└── ... (other files)
```

## CI/CD Pipeline (GitHub Actions)

### Automatic Builds

Every push to `main` branch triggers:

1. **Checkout** code
2. **Setup** Java 17
3. **Build** debug APK (~3-5 minutes)
4. **Upload** APK as artifact (30-day retention)

### Access Built APK

1. Go to GitHub repo → **Actions** tab
2. Click latest workflow run
3. Under **Artifacts**, download `iftar-timer-debug-apk.zip`
4. Extract and install: `adb install app-debug.apk`

### Custom Workflows

Edit `.github/workflows/android-build.yml` to:
- Change trigger branch (e.g., `develop`)
- Add additional build steps (lint, tests)
- Publish to Play Store
- Create GitHub release

## Security Considerations

### Permissions

The app requests:
- `ACCESS_FINE_LOCATION` - GPS
- `ACCESS_COARSE_LOCATION` - Network/cell location
- `INTERNET` - Time zone data (future enhancement)

**Privacy:** Location is stored locally only, never sent to servers.

### Data Storage

- SharedPreferences stores latitude, longitude, city name
- No analytics, no tracking
- No ads or third-party SDKs
- Open source (code auditable)

## Performance Optimization

### APK Size
- Target size: 3-5 MB
- Uses vector drawables (no PNG images)
- Minimal dependencies
- No unused resources

### Battery Usage
- Widget updates every 60 seconds (configurable)
- Uses AlarmManager efficiently
- Location updates on-demand only

### Memory Usage
- ~20 MB runtime memory
- No memory leaks (tested)
- Efficient prayer calculation algorithm

## Support & Documentation

- **README.md** - Project overview
- **PROJECT_STRUCTURE.md** - File structure
- **SETUP.md** - This file
- **Inline comments** in Java code
- **Google Android Docs**: https://developer.android.com/

## Common Commands Reference

```bash
# Build
./gradlew assembleDebug              # Build debug APK
./gradlew assembleRelease            # Build release APK
./gradlew clean                      # Clean build files

# Install & Run
adb install app-debug.apk            # Install APK
adb uninstall com.iftar.timer        # Uninstall app
adb shell am start .MainActivity     # Launch app

# Testing
./gradlew test                       # Unit tests
./gradlew connectedAndroidTest       # Device tests

# Development
./gradlew lint                       # Code analysis
./gradlew dependencies               # Show dependencies
```

## Next Steps

1. ✅ Extract/clone project files
2. ✅ Open in Android Studio
3. ✅ Build debug APK
4. ✅ Install on device
5. ✅ Grant location permission
6. ✅ Add widget to home screen
7. 📝 Customize as needed
8. 🚀 Deploy to Play Store (optional)

## Questions?

- Check README.md for feature overview
- Check PROJECT_STRUCTURE.md for file details
- Check inline Java comments for code details
- Visit Android developer docs
- Open GitHub issues for bugs

---

**Happy coding! Enjoy your Iftar Timer app! 🌙📱**
