package com.iftar.timer.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.widget.RemoteViews;

import androidx.core.content.ContextCompat;

import com.iftar.timer.MainActivity;
import com.iftar.timer.R;
import com.iftar.timer.util.LocationManager;
import com.iftar.timer.util.PrayerTimeCalculator;

import java.util.Calendar;

/**
 * Widget provider for Iftar countdown widget
 * Updates every minute with countdown to Maghrib
 */
public class IftarWidgetProvider extends AppWidgetProvider {

    private static final String ACTION_WIDGET_UPDATE = "com.iftar.timer.UPDATE_WIDGET";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
        scheduleNextUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (ACTION_WIDGET_UPDATE.equals(intent.getAction())) {
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            int[] appWidgetIds = appWidgetManager.getAppWidgetIds(
                    new android.content.ComponentName(context, IftarWidgetProvider.class));

            for (int appWidgetId : appWidgetIds) {
                updateWidget(context, appWidgetManager, appWidgetId);
            }
            scheduleNextUpdate(context);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Get location
        LocationManager locationManager = new LocationManager(context);
        Location location = locationManager.getSavedOrDefaultLocation();

        // Calculate prayer times
        Calendar calendar = Calendar.getInstance();
        PrayerTimeCalculator calculator = new PrayerTimeCalculator(
                location.getLatitude(),
                location.getLongitude()
        );

        int maghribMinutes = calculator.getMaghribTimeInMinutes(calendar);

        // Get countdown
        int countdownMinutes = PrayerTimeCalculator.getCountdownMinutes(calendar, maghribMinutes);
        if (countdownMinutes == 0) {
            countdownMinutes = PrayerTimeCalculator.getMinutesUntilNextMaghrib(calendar, maghribMinutes);
        }

        // Format time
        int hours = countdownMinutes / 60;
        int mins = countdownMinutes % 60;
        String countdownText = String.format("%02d:%02d", hours, mins);
        String maghribText = PrayerTimeCalculator.formatTime(maghribMinutes);

        // Create remote views
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_iftar);
        views.setTextViewText(R.id.widget_countdown, countdownText);
        views.setTextViewText(R.id.widget_maghrib_time, maghribText);

        // Set click intent to open main activity
        Intent intent = new Intent(context, MainActivity.class);
        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(
                context, 0, intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);

        // Update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static void scheduleNextUpdate(Context context) {
        // Schedule next update in 1 minute
        long nextUpdateTime = System.currentTimeMillis() + 60000;

        Intent intent = new Intent(context, IftarWidgetProvider.class);
        intent.setAction(ACTION_WIDGET_UPDATE);

        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getBroadcast(
                context, 0, intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE
        );

        android.app.AlarmManager alarmManager = (android.app.AlarmManager) context.getSystemService(
                Context.ALARM_SERVICE);

        if (alarmManager != null) {
            try {
                alarmManager.setAndAllowWhileIdle(
                        android.app.AlarmManager.RTC_WAKEUP,
                        nextUpdateTime,
                        pendingIntent
                );
            } catch (Exception e) {
                // Silently handle if alarm permission not available
            }
        }
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleNextUpdate(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }
}
