package com.iftar.timer.util;

import android.os.StrictMode;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;

/**
 * Accurate Maghrib calculator with:
 * 1) Online API (Aladhan) when internet available
 * 2) Offline solar fallback
 * 3) 12-hour formatted time
 */
public class PrayerTimeCalculator {

    private double latitude;
    private double longitude;

    public PrayerTimeCalculator(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;

        // Allow network call (simple approach for small app)
        StrictMode.setThreadPolicy(
                new StrictMode.ThreadPolicy.Builder().permitAll().build()
        );
    }

    // =========================================================
    // ⭐ MAIN METHOD — ONLINE FIRST, OFFLINE FALLBACK
    // =========================================================

    public int getMaghribTimeInMinutes(Calendar calendar) {

        Integer apiTime = getMaghribFromAPI(calendar);

        if (apiTime != null) {
            return apiTime; // 🌐 Accurate online time
        }

        return getOfflineMaghrib(calendar); // 🌙 Offline fallback
    }

    // =========================================================
    // 🌐 ONLINE: Fetch from Aladhan API
    // =========================================================

    private Integer getMaghribFromAPI(Calendar calendar) {

        try {
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH) + 1;
            int year = calendar.get(Calendar.YEAR);

            String urlStr =
                    "https://api.aladhan.com/v1/timings/"
                            + day + "-" + month + "-" + year
                            + "?latitude=" + latitude
                            + "&longitude=" + longitude
                            + "&method=2"; // ISNA method

            URL url = new URL(urlStr);
            HttpURLConnection conn =
                    (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");
            conn.setConnectTimeout(4000);

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(conn.getInputStream())
                    );

            StringBuilder result = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }

            JSONObject json = new JSONObject(result.toString());

            String maghrib =
                    json.getJSONObject("data")
                        .getJSONObject("timings")
                        .getString("Maghrib");

            // Format "18:05"
            String[] parts = maghrib.split(":");
            int hours = Integer.parseInt(parts[0]);
            int mins = Integer.parseInt(parts[1]);

            return hours * 60 + mins;

        } catch (Exception e) {
            return null; // fallback to offline
        }
    }

    // =========================================================
    // 🌙 OFFLINE: Accurate Solar Sunset Calculation
    // =========================================================

    private int getOfflineMaghrib(Calendar calendar) {

        int dayOfYear = calendar.get(Calendar.DAY_OF_YEAR);

        double latRad = Math.toRadians(latitude);

        // Solar declination
        double decl = Math.toRadians(
                23.45 * Math.sin(Math.toRadians(
                        (360.0 / 365.0) * (284 + dayOfYear)
                ))
        );

        // Equation of Time
        double B = Math.toRadians((360.0 / 365.0) * (dayOfYear - 81));
        double EoT = 9.87 * Math.sin(2 * B)
                - 7.53 * Math.cos(B)
                - 1.5 * Math.sin(B);

        double timezone = 6.0; // Bangladesh UTC+6
        double LSTM = 15 * timezone;

        double TC = 4 * (longitude - LSTM) + EoT;

        double solarNoon = 720 - TC;

        // Sunset angle
        double cosH = (
                Math.cos(Math.toRadians(90.833))
                        - Math.sin(latRad) * Math.sin(decl)
        ) / (Math.cos(latRad) * Math.cos(decl));

        if (cosH > 1) cosH = 1;
        if (cosH < -1) cosH = -1;

        double H = Math.toDegrees(Math.acos(cosH));

        double sunsetMinutes = solarNoon + (H * 4);

        return (int) sunsetMinutes;
    }

    // =========================================================
    // 🕰️ FORMAT TIME — 12 HOUR (AM/PM)
    // =========================================================

    public static String formatTime(int minutes) {

        int hours24 = minutes / 60;
        int mins = minutes % 60;

        String ampm = (hours24 >= 12) ? "PM" : "AM";

        int hours12 = hours24 % 12;
        if (hours12 == 0) hours12 = 12;

        return String.format("%d:%02d %s", hours12, mins, ampm);
    }

    // =========================================================
    // ⏳ COUNTDOWN METHODS
    // =========================================================

    public static int getCountdownMinutes(Calendar calendar, int maghribMinutes) {

        int current =
                calendar.get(Calendar.HOUR_OF_DAY) * 60
                        + calendar.get(Calendar.MINUTE);

        return Math.max(0, maghribMinutes - current);
    }

    public static int getMinutesUntilNextMaghrib(
            Calendar calendar, int maghribMinutes) {

        int current =
                calendar.get(Calendar.HOUR_OF_DAY) * 60
                        + calendar.get(Calendar.MINUTE);

        if (current < maghribMinutes) {
            return maghribMinutes - current;
        }

        return (24 * 60) - current + maghribMinutes;
    }
}