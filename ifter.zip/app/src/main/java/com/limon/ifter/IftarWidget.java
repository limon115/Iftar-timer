import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import java.util.Calendar;

public class IftarWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context,
                         AppWidgetManager manager,
                         int[] ids) {

        for (int id : ids) {

            RemoteViews views = new RemoteViews(
                    context.getPackageName(),
                    R.layout.widget_iftar);

            // Approx Maghrib time (Dhaka)
            Calendar now = Calendar.getInstance();
            Calendar maghrib = Calendar.getInstance();
            maghrib.set(Calendar.HOUR_OF_DAY, 18);
            maghrib.set(Calendar.MINUTE, 5);

            long diff = maghrib.getTimeInMillis()
                       - now.getTimeInMillis();

            if (diff < 0) diff = 0;

            long minutes = diff / 60000;
            long hours = minutes / 60;
            minutes = minutes % 60;

            String countdown =
                    hours + "h " + minutes + "m";

            views.setTextViewText(
                    R.id.countdown,
                    countdown);

            manager.updateAppWidget(id, views);
        }
    }
}