# 📦 IFTAR TIMER - COMPLETE DIRECTORY TREE

## Visual Project Structure

```
iftar-timer-project/                                    [PROJECT ROOT - 112 KB]
│
├── 📄 START_HERE.md                                   ← Start reading here!
├── 📄 README.md                                        ← Project overview
├── 📄 SETUP.md                                         ← Detailed setup guide
├── 📄 PROJECT_STRUCTURE.md                            ← File reference
├── 📄 FILE_MANIFEST.md                                ← File descriptions
│
├── 🔧 build.gradle                                     [Project-level Gradle config]
├── 🔧 settings.gradle                                  [Gradle settings]
├── 📝 .gitignore                                       [Git ignore rules]
│
├── 📂 gradle/
│   └── wrapper/
│       └── 🔧 gradle-wrapper.properties               [Gradle wrapper config]
│
├── 📂 .github/
│   └── workflows/
│       └── ⚙️ android-build.yml                       [GitHub Actions CI/CD]
│
├── 📂 app/                                             [MAIN APP MODULE]
│   │
│   ├── 🔧 build.gradle                               [App-level Gradle config]
│   ├── 📝 proguard-rules.pro                          [Code obfuscation rules]
│   │
│   └── 📂 src/main/
│       │
│       ├── 📝 AndroidManifest.xml                     [App manifest]
│       │
│       ├── 📂 java/com/iftar/timer/
│       │   │
│       │   ├── 💻 MainActivity.java                   [Main activity]
│       │   │   └── ├─ Countdown display
│       │   │       ├─ Location handling
│       │   │       ├─ Permission requests
│       │   │       └─ UI updates every 60s
│       │   │
│       │   ├── 📂 util/
│       │   │   │
│       │   │   ├── 💻 PrayerTimeCalculator.java      [Offline calculations]
│       │   │   │   └─ ├─ Maghrib time calculation
│       │   │   │      ├─ Sun declination
│       │   │   │      ├─ Prayer angle math
│       │   │   │      └─ Countdown formatting
│       │   │   │
│       │   │   └── 💻 LocationManager.java           [GPS/Location handling]
│       │   │       └─ ├─ FusedLocationProviderClient
│       │   │          ├─ SharedPreferences caching
│       │   │          ├─ Permission checks
│       │   │          ├─ Dhaka fallback
│       │   │          └─ Location callbacks
│       │   │
│       │   └── 📂 widget/
│       │       │
│       │       ├── 💻 IftarWidgetProvider.java       [Widget provider]
│       │       │   └─ ├─ Updates every 60 seconds
│       │       │      ├─ Displays countdown
│       │       │      ├─ Opens app on tap
│       │       │      └─ AlarmManager scheduling
│       │       │
│       │       └── 💻 WidgetUpdateReceiver.java      [Widget updates]
│       │           └─ ├─ Handles update broadcasts
│       │              └─ Fallback update mechanism
│       │
│       └── 📂 res/
│           │
│           ├── 📂 layout/                            [UI Layouts]
│           │   │
│           │   ├── 📄 activity_main.xml              [Main activity layout]
│           │   │   └─ ├─ LinearLayout (vertical)
│           │   │      ├─ Location text
│           │   │      ├─ "IFTAR" label
│           │   │      ├─ Large countdown (72sp)
│           │   │      ├─ Maghrib time display
│           │   │      ├─ Refresh button
│           │   │      └─ App info text
│           │   │
│           │   └── 📄 widget_iftar.xml               [Widget layout]
│           │       └─ ├─ FrameLayout with glass bg
│           │          ├─ "IFTAR" label (12sp)
│           │          ├─ Countdown display (48sp)
│           │          ├─ Maghrib time (14sp)
│           │          └─ Click handler → MainActivity
│           │
│           ├── 📂 drawable/                          [Drawable Resources]
│           │   │
│           │   ├── 🎨 ic_launcher_foreground.xml    [Icon foreground]
│           │   │   └─ White clock/timer symbol
│           │   │
│           │   ├── 🎨 ic_launcher_background.xml    [Icon background]
│           │   │   └─ Primary green (#2E7D32)
│           │   │
│           │   ├── 🎨 widget_glass_bg.xml           [Widget glass effect]
│           │   │   └─ ├─ 30% opacity white
│           │   │      ├─ White border
│           │   │      └─ 28dp rounded corners
│           │   │
│           │   └── 🎨 widget_preview.xml            [Widget preview]
│           │       └─ Dark placeholder image
│           │
│           ├── 📂 mipmap-anydpi-v26/                [Adaptive icons (Android 8+)]
│           │   │
│           │   ├── 📄 ic_launcher.xml               [Main adaptive icon]
│           │   │   └─ Background + Foreground combo
│           │   │
│           │   └── 📄 ic_launcher_round.xml         [Round variant]
│           │       └─ Circular icon option
│           │
│           ├── 📂 mipmap-anydpi-v33/                [Modern icons (Android 13+)]
│           │   │
│           │   └── 📄 ic_launcher.xml               [Themed adaptive icon]
│           │       └─ System theme support
│           │
│           ├── 📂 values/                           [String/Color Resources]
│           │   │
│           │   ├── 📄 strings.xml                   [Text strings]
│           │   │   └─ ├─ app_name
│           │   │      ├─ iftar_label
│           │   │      ├─ default_location
│           │   │      ├─ maghrib_time_default
│           │   │      ├─ refresh_location
│           │   │      ├─ app_info
│           │   │      └─ widget_name
│           │   │
│           │   ├── 📄 colors.xml                    [Color definitions]
│           │   │   └─ ├─ primary (green)
│           │   │      ├─ primary_variant
│           │   │      ├─ secondary (teal)
│           │   │      ├─ background colors
│           │   │      ├─ text colors
│           │   │      ├─ status bar colors
│           │   │      └─ nav bar colors
│           │   │
│           │   └── 📄 styles.xml                    [App themes]
│           │       └─ ├─ Theme.IftarTimer
│           │          ├─ ActionBarStyle
│           │          └─ MaterialButtonStyle
│           │
│           └── 📂 xml/                              [Configuration XMLs]
│               │
│               ├── 📄 iftar_widget_info.xml         [Widget metadata]
│               │   └─ ├─ Size: 250x100 dp
│               │      ├─ Update period: 3600s
│               │      ├─ Grid: 4x2
│               │      ├─ Resizable: horizontal/vertical
│               │      └─ Category: home_screen
│               │
│               ├── 📄 backup_rules.xml              [Android 12+ backup]
│               │   └─ SharedPreferences backup
│               │
│               └── 📄 data_extraction_rules.xml     [Android 12+ extraction]
│                   └─ No cleartext traffic allowed
│
├── 📄 gradlew                                        [Unix/Linux/Mac build script]
├── 📄 gradlew.bat                                    [Windows build script]
│
└── 📂 app/build/                                    [Generated on build]
    └── outputs/apk/debug/
        └── app-debug.apk                           ← Your APK (created by build)
```

## 📊 Statistics at a Glance

```
TOTAL FILES:           35+
├── Java Classes       5
├── Layout XMLs        2
├── Drawable XMLs      4
├── Resource XMLs      3
├── Config XMLs        3
├── Icon XMLs          3
├── Build Config       4
├── CI/CD              1
├── Documentation      4
└── Other             2

PROJECT SIZE:         112 KB (source)
BUILD OUTPUT:         ~5 MB (debug APK)
MIN SDK:              21 (Android 5.0)
TARGET SDK:           34 (Android 14)
DEPENDENCIES:         7 (AndroidX + Google Play Services)
```

## 🗂️ Directory Breakdown

### Root Level (8 files)
```
├── START_HERE.md ...................... Entry point (📌 READ FIRST)
├── README.md .......................... Feature overview
├── SETUP.md ........................... Setup instructions
├── PROJECT_STRUCTURE.md .............. File reference
├── FILE_MANIFEST.md .................. File descriptions
├── build.gradle ....................... Project config
├── settings.gradle .................... Gradle settings
└── .gitignore ......................... Git rules
```

### gradle/ (1 file)
```
gradle/
└── wrapper/
    └── gradle-wrapper.properties ..... Gradle version config
```

### .github/ (1 file)
```
.github/
└── workflows/
    └── android-build.yml ............ GitHub Actions
```

### app/src/main/java/ (5 files)
```
app/src/main/java/com/iftar/timer/
├── MainActivity.java ................ Main activity
├── util/
│   ├── PrayerTimeCalculator.java ... Prayer calculations
│   └── LocationManager.java ........ Location/GPS handling
└── widget/
    ├── IftarWidgetProvider.java ... Widget provider
    └── WidgetUpdateReceiver.java .. Widget updates
```

### app/src/main/res/layout/ (2 files)
```
├── activity_main.xml ............... Main UI
└── widget_iftar.xml ............... Widget UI
```

### app/src/main/res/drawable/ (4 files)
```
├── ic_launcher_foreground.xml ... Icon foreground
├── ic_launcher_background.xml .. Icon background
├── widget_glass_bg.xml ......... Widget glass effect
└── widget_preview.xml .......... Widget preview
```

### app/src/main/res/values/ (3 files)
```
├── strings.xml ........... Text resources
├── colors.xml ........... Color definitions
└── styles.xml ........... App themes
```

### app/src/main/res/xml/ (3 files)
```
├── iftar_widget_info.xml ....... Widget config
├── backup_rules.xml ........... Backup config
└── data_extraction_rules.xml .. Data rules
```

### app/src/main/res/mipmap-* (3 files)
```
├── mipmap-anydpi-v26/ic_launcher.xml
├── mipmap-anydpi-v26/ic_launcher_round.xml
└── mipmap-anydpi-v33/ic_launcher.xml
```

## 🎯 Quick File Lookup

### "I need to change..."

| What | File | Line |
|------|------|------|
| App colors | values/colors.xml | All |
| App text | values/strings.xml | All |
| Widget size | xml/iftar_widget_info.xml | Line 3-4 |
| Default location | util/LocationManager.java | 26-27 |
| Countdown display | layout/activity_main.xml | ~25 |
| Widget appearance | drawable/widget_glass_bg.xml | 4-8 |
| App icon | drawable/ic_launcher_*.xml | All |
| Build version | app/build.gradle | 16-18 |
| Dependencies | app/build.gradle | 45+ |
| Widget update time | widget/IftarWidgetProvider.java | ~67 |

## 📱 Build Output Paths

```
app/build/
├── outputs/
│   └── apk/
│       ├── debug/
│       │   └── app-debug.apk              ← Use this for testing
│       └── release/
│           └── app-release.apk            ← For Play Store (requires signing)
│
├── intermediates/
│   └── [Compiled resources, dex files, etc.]
│
└── generated/
    └── [Auto-generated code, R.java, etc.]
```

## 🔄 Dependency Tree

```
MainActivity
├── LocationManager
│   ├── SharedPreferences
│   ├── FusedLocationProviderClient
│   └── Handler (Looper)
└── PrayerTimeCalculator
    └── Calendar

IftarWidgetProvider
├── LocationManager
├── PrayerTimeCalculator
├── AlarmManager
├── RemoteViews
└── AppWidgetManager

WidgetUpdateReceiver
└── IftarWidgetProvider
```

## 🎨 Resource Dependencies

```
activity_main.xml
├── values/strings.xml (text references)
├── values/colors.xml (color references)
└── values/styles.xml (theme)

widget_iftar.xml
├── drawable/widget_glass_bg.xml
├── values/strings.xml
└── RemoteViews (updated programmatically)

Manifest
├── java/* (component declarations)
├── drawable/* (icon references)
├── values/strings.xml (names)
└── xml/* (metadata)
```

## 🔐 File Permissions Summary

| File/Directory | Type | Permission | Status |
|---|---|---|---|
| gradlew | Script | Executable | ✓ Execute on Unix/Mac |
| gradlew.bat | Script | Executable | ✓ Execute on Windows |
| .gradle/ | Directory | Read/Write | ✓ Generated automatically |
| build/ | Directory | Read/Write | ✓ Generated automatically |
| .idea/ | Directory | Read/Write | ✓ IDE generated |
| *.java | Source | Read-Only | ✓ In version control |
| *.xml | Resource | Read-Only | ✓ In version control |
| build.gradle | Config | Read-Only | ✓ In version control |
| gradlew* | Script | Read-Only | ✓ In version control |

## 💾 Storage Locations

### SharedPreferences (LocalStorage)
```
Location: data/data/com.iftar.timer/shared_prefs/iftar_timer_prefs.xml
Contains:
├── latitude (float)
├── longitude (float)
└── city_name (string)
```

### Generated Files (On Build)
```
app/build/
├── generated/         (R.java, BuildConfig.java)
├── intermediates/     (Compiled classes, resources)
├── outputs/           (Final APK files)
└── tmp/               (Temporary build files)
```

### Gradle Cache
```
.gradle/               (Downloaded dependencies)
gradle/wrapper/       (Gradle distribution)
```

## 🔗 File Relationships

```
MANIFEST
├─── Declares Components
│    ├── MainActivity (layout: activity_main.xml)
│    ├── IftarWidgetProvider (layout: widget_iftar.xml)
│    └── WidgetUpdateReceiver
│
└─── Declares Permissions
     ├── ACCESS_FINE_LOCATION
     ├── ACCESS_COARSE_LOCATION
     └── INTERNET

GRADLE
├─── Downloads Dependencies
│    ├── com.google.android.gms:play-services-location
│    ├── androidx.appcompat:appcompat
│    └── ... (6 more)
│
└─── Defines Build Settings
     ├── SDK versions
     ├── App ID
     ├── Version number
     └── Compiler options

RESOURCES
├─── values/strings.xml (text)
├─── values/colors.xml (colors)
├─── values/styles.xml (themes)
├─── drawable/*.xml (images)
├─── layout/*.xml (UI layouts)
├─── mipmap/*.xml (icons)
└─── xml/*.xml (config)

CODE
├─── MainActivity.java
│    ├── Uses: LocationManager
│    ├── Uses: PrayerTimeCalculator
│    └── Displays: activity_main.xml
│
├─── IftarWidgetProvider.java
│    ├── Uses: LocationManager
│    ├── Uses: PrayerTimeCalculator
│    └── Updates: widget_iftar.xml
│
├─── LocationManager.java
│    ├── Caches: SharedPreferences
│    └── Uses: FusedLocationProviderClient
│
├─── PrayerTimeCalculator.java
│    └── Pure calculations (no dependencies)
│
└─── WidgetUpdateReceiver.java
     └── Triggers: IftarWidgetProvider
```

## 📈 Build Process Flow

```
source code files
         ↓
    ┌────────────────────────────────────┐
    │  Gradle Build Process             │
    │ ./gradlew assembleDebug           │
    └────────────────────────────────────┘
         ↓
    ┌────────────────────────────────────┐
    │  1. Compile Java Files             │
    │     app/src/main/java/*.java       │
    │     → .class files                 │
    └────────────────────────────────────┘
         ↓
    ┌────────────────────────────────────┐
    │  2. Compile Resources              │
    │     app/src/main/res/*             │
    │     → resource IDs (R.java)        │
    └────────────────────────────────────┘
         ↓
    ┌────────────────────────────────────┐
    │  3. DEX Compilation                │
    │     .class files → .dex            │
    └────────────────────────────────────┘
         ↓
    ┌────────────────────────────────────┐
    │  4. Package APK                    │
    │     .dex + resources + manifest    │
    │     → app-debug.apk                │
    └────────────────────────────────────┘
         ↓
    app/build/outputs/apk/debug/app-debug.apk
```

## 🚀 Getting Started Checklist

- [ ] Read START_HERE.md (5 min)
- [ ] Read SETUP.md (10 min)
- [ ] Extract project files
- [ ] Make gradlew executable: `chmod +x gradlew`
- [ ] Run: `./gradlew assembleDebug` (first time: 5-10 min)
- [ ] Locate APK: `app/build/outputs/apk/debug/app-debug.apk`
- [ ] Install: `adb install [APK path]`
- [ ] Test on device
- [ ] Customize as needed
- [ ] Push to GitHub for CI/CD

## 📞 Finding Help

| Topic | File |
|-------|------|
| Quick start | START_HERE.md |
| Setup details | SETUP.md |
| File listing | PROJECT_STRUCTURE.md |
| File details | FILE_MANIFEST.md |
| Build help | This file |
| Feature docs | README.md |
| Code comments | Source files in /java/ |

---

## Summary

**35 files organized in a standard Android Studio project structure**
- Ready to build with Gradle
- Ready to deploy to devices
- Ready for GitHub Actions CI/CD
- Fully documented and explained

**Total Size**: 112 KB source code
**Build Output**: ~5 MB APK
**Build Time**: 2-5 minutes (first time), 1-2 minutes (incremental)

**Next Action**: Open START_HERE.md and begin! 🚀

---

*Complete Directory Tree & Quick Reference*
*February 2026 - Version 1.0.0*
