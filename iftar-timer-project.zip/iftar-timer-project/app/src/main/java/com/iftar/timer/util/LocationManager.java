package com.iftar.timer.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;

import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.Task;

import android.Manifest;

/**
 * Manages location retrieval using FusedLocationProviderClient
 * Falls back to stored location or Dhaka if GPS unavailable
 */
public class LocationManager {

    private static final String PREFS_NAME = "iftar_timer_prefs";
    private static final String PREF_LATITUDE = "latitude";
    private static final String PREF_LONGITUDE = "longitude";
    private static final String PREF_CITY = "city_name";

    // Default Dhaka coordinates
    private static final double DEFAULT_LATITUDE = 23.8103;
    private static final double DEFAULT_LONGITUDE = 90.2293;
    private static final String DEFAULT_CITY = "Dhaka, Bangladesh";

    private FusedLocationProviderClient fusedLocationClient;
    private SharedPreferences preferences;

    public LocationManager(Context context) {
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
        this.preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Get last known location from device
     * Falls back to saved location or Dhaka
     */
    @SuppressLint("MissingPermission")
    public Location getLastKnownLocation(Context context) {
        // Check if permissions are granted
        if (!hasLocationPermissions(context)) {
            return getSavedOrDefaultLocation();
        }

        try {
            Task<Location> task = fusedLocationClient.getLastLocation();
            task.addOnSuccessListener(location -> {
                if (location != null) {
                    saveLocation(location);
                }
            });

            task.addOnFailureListener(e -> {
                // Silently fail - we have fallbacks
            });
        } catch (Exception e) {
            // Fallback to saved/default
        }

        return getSavedOrDefaultLocation();
    }

    /**
     * Request fresh location update
     */
    @SuppressLint("MissingPermission")
    public void requestLocationUpdate(Context context, LocationCallback callback) {
        if (!hasLocationPermissions(context)) {
            callback.onLocationFailed();
            return;
        }

        try {
            Task<Location> task = fusedLocationClient.getCurrentLocation(
                    Priority.PRIORITY_BALANCED_POWER_ACCURACY, null);

            task.addOnSuccessListener(location -> {
                if (location != null) {
                    saveLocation(location);
                    callback.onLocationReceived(location);
                } else {
                    callback.onLocationFailed();
                }
            });

            task.addOnFailureListener(e -> callback.onLocationFailed());
        } catch (Exception e) {
            callback.onLocationFailed();
        }
    }

    /**
     * Get saved location from SharedPreferences or default to Dhaka
     */
    public Location getSavedOrDefaultLocation() {
        double latitude = preferences.getFloat(PREF_LATITUDE, (float) DEFAULT_LATITUDE);
        double longitude = preferences.getFloat(PREF_LONGITUDE, (float) DEFAULT_LONGITUDE);

        Location location = new Location("saved");
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        return location;
    }

    /**
     * Save location to SharedPreferences
     */
    private void saveLocation(Location location) {
        preferences.edit()
                .putFloat(PREF_LATITUDE, (float) location.getLatitude())
                .putFloat(PREF_LONGITUDE, (float) location.getLongitude())
                .apply();

        // Save city name (simplified - just use coordinates)
        String city = getCityName(location.getLatitude(), location.getLongitude());
        preferences.edit().putString(PREF_CITY, city).apply();
    }

    /**
     * Get saved city name
     */
    public String getSavedCityName() {
        return preferences.getString(PREF_CITY, DEFAULT_CITY);
    }

    /**
     * Simple city mapping based on coordinates
     * In production, this would use reverse geocoding
     */
    private String getCityName(double latitude, double longitude) {
        // Check if coordinates are close to known cities
        double dhakaLat = 23.8103;
        double dhakaLon = 90.2293;

        double distance = Math.sqrt(
                Math.pow(latitude - dhakaLat, 2) + Math.pow(longitude - dhakaLon, 2)
        );

        // If within ~2 degrees of Dhaka
        if (distance < 2.0) {
            return "Dhaka, Bangladesh";
        }

        // Other major BD cities could be added here
        return String.format("%.2f°N, %.2f°E", latitude, longitude);
    }

    /**
     * Check if location permissions are granted
     */
    public static boolean hasLocationPermissions(Context context) {
        return ContextCompat.checkSelfPermission(context,
                Manifest.permission.ACCESS_FINE_LOCATION) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Callback interface for location updates
     */
    public interface LocationCallback {
        void onLocationReceived(Location location);
        void onLocationFailed();
    }
}
