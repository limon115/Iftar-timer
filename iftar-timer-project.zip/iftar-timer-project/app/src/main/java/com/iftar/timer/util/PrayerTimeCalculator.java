package com.iftar.timer.util;

import java.util.Calendar;

/**
 * Calculates prayer times based on location coordinates.
 * Uses astronomical formulas for accurate calculation.
 * Based on ISNA (Islamic Society of North America) standards.
 */
public class PrayerTimeCalculator {

    private static final double FAJR_ANGLE = 15.0;
    private static final double ISHA_ANGLE = 15.0;
    private static final double MADHAB = 4.0; // Standard madhab (4th juristic method)

    private double latitude;
    private double longitude;

    public PrayerTimeCalculator(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * Calculate Maghrib time for a given date
     *
     * @param calendar Calendar object with the date to calculate for
     * @return Time in minutes since midnight for Maghrib prayer
     */
    public int getMaghribTimeInMinutes(Calendar calendar) {
        int dayOfYear = calendar.get(Calendar.DAY_OF_YEAR);
        int year = calendar.get(Calendar.YEAR);

        // Calculate declination of the sun
        double declination = calculateDeclination(dayOfYear);

        // Calculate time difference from Greenwich
        double timeDiff = calculateTimeDifference();

        // Calculate Maghrib time using standard formula
        double sunsetAngle = -0.833; // Angle below horizon for sunset
        double maghribAngle = calculatePrayerAngle(declination, sunsetAngle);
        double maghribTime = 12.0 + timeDiff + maghribAngle;

        // Convert to 24-hour format
        while (maghribTime >= 24.0) {
            maghribTime -= 24.0;
        }
        while (maghribTime < 0.0) {
            maghribTime += 24.0;
        }

        // Add 1-2 minutes buffer for practical use
        maghribTime += 2.0 / 60.0;

        return (int) (maghribTime * 60); // Convert to minutes since midnight
    }

    /**
     * Calculate the sun's declination for a given day of year
     */
    private double calculateDeclination(int dayOfYear) {
        double n = dayOfYear - 1;
        double declination = 23.44 * Math.sin(Math.toRadians((360.0 / 365.25) * (n + 284)));
        return declination;
    }

    /**
     * Calculate time difference from Greenwich Mean Time
     * Simplified: uses latitude/longitude to estimate
     */
    private double calculateTimeDifference() {
        // Bangladesh is UTC+6 (approximately 90 degrees east)
        // Dhaka: 23.8103°N, 90.2293°E
        double timeZoneOffset = 6.0; // Bangladesh Standard Time
        return timeZoneOffset - 12.0;
    }

    /**
     * Calculate prayer angle using latitude and declination
     */
    private double calculatePrayerAngle(double declination, double angle) {
        double latRad = Math.toRadians(latitude);
        double declRad = Math.toRadians(declination);
        double angleRad = Math.toRadians(angle);

        double numerator = Math.sin(angleRad) - Math.sin(latRad) * Math.sin(declRad);
        double denominator = Math.cos(latRad) * Math.cos(declRad);

        double result = numerator / denominator;

        // Ensure result is within valid range
        if (result > 1.0) result = 1.0;
        if (result < -1.0) result = -1.0;

        double hourAngle = Math.acos(result);
        return Math.toDegrees(hourAngle) / 15.0; // Convert to hours
    }

    /**
     * Format time from minutes since midnight to HH:MM format
     */
    public static String formatTime(int minutes) {
        int hours = minutes / 60;
        int mins = minutes % 60;
        return String.format("%02d:%02d", hours, mins);
    }

    /**
     * Get countdown in minutes until Maghrib from current time
     *
     * @param calendar Calendar object with current date and time
     * @param maghribMinutes Maghrib time in minutes since midnight
     * @return Remaining minutes until Maghrib, or 0 if passed
     */
    public static int getCountdownMinutes(Calendar calendar, int maghribMinutes) {
        int currentMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE);

        if (currentMinutes < maghribMinutes) {
            return maghribMinutes - currentMinutes;
        }
        return 0; // Maghrib has passed
    }

    /**
     * Calculate minutes until next Maghrib
     */
    public static int getMinutesUntilNextMaghrib(Calendar calendar, int maghribMinutes) {
        int currentMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE);

        if (currentMinutes < maghribMinutes) {
            return maghribMinutes - currentMinutes;
        }

        // If passed, calculate for next day
        int minutesLeft = (24 * 60) - currentMinutes + maghribMinutes;
        return minutesLeft;
    }
}
