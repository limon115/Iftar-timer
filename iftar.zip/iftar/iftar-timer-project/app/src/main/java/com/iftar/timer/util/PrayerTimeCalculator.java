package com.iftar.timer.util;

import java.util.Calendar;

/**
 * Calculates Maghrib (sunset) time using astronomical formulas.
 * Works offline and uses longitude-based time correction.
 */
public class PrayerTimeCalculator {

    private double latitude;
    private double longitude;

    public PrayerTimeCalculator(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * Calculate Maghrib time for a given date
     * @param calendar Date to calculate for
     * @return Minutes since midnight (local time)
     */
    public int getMaghribTimeInMinutes(Calendar calendar) {

        int dayOfYear = calendar.get(Calendar.DAY_OF_YEAR);

        // Sun declination
        double declination = calculateDeclination(dayOfYear);

        // Time correction from longitude (hours)
        double timeDiff = calculateTimeDifference();

        // Sunset angle (-0.833° accounts for refraction + sun radius)
        double sunsetAngle = -0.833;

        double hourAngle = calculatePrayerAngle(declination, sunsetAngle);

        // Solar noon = 12:00 local solar time
        double maghribTime = 12.0 + timeDiff + hourAngle;

        // Normalize to 0–24 hours
        while (maghribTime >= 24.0) maghribTime -= 24.0;
        while (maghribTime < 0.0) maghribTime += 24.0;

        // Add small practical buffer (2 minutes)
        maghribTime += 2.0 / 60.0;

        return (int) (maghribTime * 60);
    }

    /**
     * Sun declination angle for the day
     */
    private double calculateDeclination(int dayOfYear) {
        double n = dayOfYear - 1;
        return 23.44 * Math.sin(Math.toRadians((360.0 / 365.25) * (n + 284)));
    }

    /**
     * Time difference from solar noon based on longitude
     * (Earth rotates 15° per hour)
     */
    private double calculateTimeDifference() {
        return longitude / 15.0;
    }

    /**
     * Calculate hour angle for sunset
     */
    private double calculatePrayerAngle(double declination, double angle) {

        double latRad = Math.toRadians(latitude);
        double declRad = Math.toRadians(declination);
        double angleRad = Math.toRadians(angle);

        double numerator =
                Math.sin(angleRad) - Math.sin(latRad) * Math.sin(declRad);

        double denominator =
                Math.cos(latRad) * Math.cos(declRad);

        double result = numerator / denominator;

        // Clamp for safety
        if (result > 1.0) result = 1.0;
        if (result < -1.0) result = -1.0;

        double hourAngle = Math.acos(result);

        return Math.toDegrees(hourAngle) / 15.0; // convert to hours
    }

    /**
     * Format minutes → HH:MM
     */
    public static String formatTime(int minutes) {
        int hours = minutes / 60;
        int mins = minutes % 60;
        return String.format("%02d:%02d", hours, mins);
    }

    /**
     * Minutes remaining until Maghrib today
     */
    public static int getCountdownMinutes(Calendar calendar, int maghribMinutes) {
        int currentMinutes =
                calendar.get(Calendar.HOUR_OF_DAY) * 60
                        + calendar.get(Calendar.MINUTE);

        return Math.max(0, maghribMinutes - currentMinutes);
    }

    /**
     * Minutes until next Maghrib (today or tomorrow)
     */
    public static int getMinutesUntilNextMaghrib(Calendar calendar, int maghribMinutes) {

        int currentMinutes =
                calendar.get(Calendar.HOUR_OF_DAY) * 60
                        + calendar.get(Calendar.MINUTE);

        if (currentMinutes < maghribMinutes) {
            return maghribMinutes - currentMinutes;
        }

        // After Maghrib → next day
        return (24 * 60) - currentMinutes + maghribMinutes;
    }
}
