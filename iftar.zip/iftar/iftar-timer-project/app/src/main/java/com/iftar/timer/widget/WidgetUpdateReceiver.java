package com.iftar.timer.widget;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Broadcast receiver for widget update notifications
 */
public class WidgetUpdateReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null && intent.getAction().equals("com.iftar.timer.UPDATE_WIDGET")) {
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            int[] appWidgetIds = appWidgetManager.getAppWidgetIds(
                    new android.content.ComponentName(context, IftarWidgetProvider.class));

            IftarWidgetProvider widgetProvider = new IftarWidgetProvider();
            widgetProvider.onUpdate(context, appWidgetManager, appWidgetIds);
        }
    }
}
